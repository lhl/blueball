#ifndef LIGHTBLUEOBEX_SERVER_H
#define LIGHTBLUEOBEX_SERVER_H

#include "Python.h"

PyTypeObject *lightblueobex_getservertype(void);


#endif
