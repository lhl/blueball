#ifndef LIGHTBLUEOBEX_CLIENT_H
#define LIGHTBLUEOBEX_CLIENT_H

#include "Python.h"

PyTypeObject *lightblueobex_getclienttype(void);


#endif
